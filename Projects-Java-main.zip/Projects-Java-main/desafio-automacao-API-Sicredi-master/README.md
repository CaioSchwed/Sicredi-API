Teste Sicred API Automação.



Automação de Api'S para Sicredi